package com.squishy.rickandmortyguide.listener;

public interface NetworkInterface {
    void noInternet();
    void updateUI();
}
